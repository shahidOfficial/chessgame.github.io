<ul class="navbar-list">
	<li class="navbar-list-item">
		<div class="user-menu">
			<a href="#" class="nav-link beep">
				<i class="far fa-envelope"></i>
			</a>
			<div class="user-menu-settings">
				<div class="user-menu-header">
					<b>Messages</b>
					<div class="float-right">
						<a href="#">Mark All As Read</a>
					</div>
				</div>
				<ul class="user-menu-list">
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>shahid said</b>
								<span>ssfasfasdfdfaasdfas</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>ali said</b>
								<span>hello man</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>Kusnaedi</b>
								<span>safafasdfasfasdfasdfafasfsafasdfasafasfasdfassdsfsdfasfasfssfasfasdfdfaasdfas</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>Kusnaedi</b>
								<span>safafasdfasfasdfasdfafasfsafasdfasafasfasdfassdsfsdfasfasfssfasfasdfdfaasdfas</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>Kusnaedi</b>
								<span>safafasdfasfasdfasdfafasfsafasdfasafasfasdfassdsfsdfasfasfssfasfasdfdfaasdfas</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
				</ul>
				<div class="user-menu-footer">
					<a href="#">View All <i class="fas fa-chevron-right"></i></a>
				</div>
			</div>
		</div>
	</li>
	<li class="navbar-list-item">
		<div class="user-menu">
			<a href="#" class="nav-link beep">
				<i class="far fa-bell"></i>
			</a>
			<div class="user-menu-settings">
				<div class="user-menu-header">
					<b>Notifications</b>
					<div class="float-right">
						<a href="#">Mark All As Read</a>
					</div>
				</div>
				<ul class="user-menu-list">
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>Kusnaedi</b>
								<span>safafasdfasfasdfasdfafasfsafasdfasafasfasdfassdsfsdfasfasfssfasfasdfdfaasdfas</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>Kusnaedi</b>
								<span>safafasdfasfasdfasdfafasfsafasdfasafasfasdfassdsfsdfasfasfssfasfasdfdfaasdfas</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>Kusnaedi</b>
								<span>safafasdfasfasdfasdfafasfsafasdfasafasfasdfassdsfsdfasfasfssfasfasdfdfaasdfas</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>Kusnaedi</b>
								<span>safafasdfasfasdfasdfafasfsafasdfasafasfasdfassdsfsdfasfasfssfasfasdfdfaasdfas</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
					<li class="user-menu-list-item user-menu-list-item-read">
						<a href="#" class="">
							<div class="user-menu-item-img">
								<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="rounded-circle user-img">
								<div class="is-online"></div>
							</div>
							<div class="user-menu-item-text">
								<b>Kusnaedi</b>
								<span>safafasdfasfasdfasdfafasfsafasdfasafasfasdfassdsfsdfasfasfssfasfasdfdfaasdfas</span>
								<p class="item-age">10 Mins Ago</p>
							</div>
						</a>
					</li>
				</ul>
				<div class="user-menu-footer">
					<a href="#">View All <i class="fas fa-chevron-right"></i></a>
				</div>
			</div>
		</div>
	</li>
	<li class="navbar-list-item">
		<div class="user-name">
			<a href="#" class="user-name">
				<img alt="image" src="<?php echo base_url(); ?>assets/img/avatar-1.png" class="user-img rounded-circle mr-1" />Player Name
			</a>
			<div class="user-menu-settings-profile">
				<div class="user-menu-header">Logged in 5 min ago</div>
				<a href="features-profile.html" class="user-menu-list-item-profile has-icon"><i class="far fa-user"></i>Profile</a>
				<a href="features-activities.html" class="user-menu-list-item-profile has-icon"><i class="fas fa-bolt"></i>Activities</a>
				<a href="features-settings.html" class="user-menu-list-item-profile has-icon"><i class="fas fa-cog"></i>Settings</a>
				<a href="#" class="user-menu-list-item-profile has-icon">
					<i class="fas fa-sign-out-alt"></i>Logout
				</a>
			</div>
		</div>
	</li>
</ul>